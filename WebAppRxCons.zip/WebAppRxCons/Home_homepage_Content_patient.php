<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
    </head>
    <frameset cols="20%,*">
        <frame name="Page_Side" scrolling="no" src="Home_homepage_Side_patient.php">
            <frame name="Page_Content" src="WelcomePage_Patient.php">
                </frameset>
                <body>
                </body>
                </html>
