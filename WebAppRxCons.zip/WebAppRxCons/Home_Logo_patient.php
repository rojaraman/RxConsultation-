<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <title>Home_Logo</title>
        <link rel="stylesheet" type="text/css" href="HomePage_Top_Style.css">

    </head>
    <body bgcolor="azure">

        <table style="height:100%;width:100%; position: absolute; top: 0; bottom: 0; left: 0; right: 0;border:1px solid">
            <tr style="width: 25%; font-size: 180px;">
                <td width="">
                    <img id="logo_image" align="right" src="images/Rx7.png" alt="Rx"
                         style="width:90px; height:90px;visibility:visible;background-color:rgb(0,114,198);">
                    <h1 align="center">R<sub>x</sub> &nbsp&nbsp&nbsp&nbspConsultation</h1>
                </td>
            </tr>
            <tr>
                <td>
                    <ul align="right">
                        <li id="Hello" style="color:white; font-size:15px">Hello !! ~~~~~~~~~&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</li>
                        <li id="Homelist"><a href="WelcomePage_Patient.php" target="Page_Content"> Home </a></li>
                        <li id="AccList"><a href="Home_Account.php" target="Page_Content"> My Account</a></li>
                        <li id="TechSupList"><a href="Home_TechSupport.php" target="Page_Content">Technical Support</a></li>
                        <li id="AboutList"><a href="Homepage_AboutUs.php" target="Page_Content">About Us</a></li>
                        <li id="SettingList"><a href="Homepage_Settings.php" target="Page_Content">Settings</a></li>
                        <li id="LogoutList"><a href="index.php" target="_parent">Logout</a></li>
                    </ul>
                </td>
            </tr>
        </table>
    </body>
</html>
