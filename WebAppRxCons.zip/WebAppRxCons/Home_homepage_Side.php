<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="HomePage_Style.css">
    </head>
    <body style="background-image: url('images/medimage.png');background-repeat:no-repeat;background-size:100%;">
        <ul>
            <li><a href="Homepage_CreateNewPres.php" target="Page_Content">Create New Prescription Current Patient</a></li>
            <li><a href="Homepage_PreviousPres.php" target="Page_Content">Previous Prescription</a><br> </li>
        </ul>
    </body>
</html>